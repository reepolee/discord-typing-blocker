console.log("content script working");
